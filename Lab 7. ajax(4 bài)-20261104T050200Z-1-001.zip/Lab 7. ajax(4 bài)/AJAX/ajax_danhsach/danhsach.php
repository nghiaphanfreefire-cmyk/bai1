
<?php
include("inc/connect.inc");

// Hàm lấy danh sách lớp
function initClass($conn) {

    $sql = "SELECT DISTINCT lop FROM sinhvien";
    $rs = mysqli_query($conn, $sql);

    echo "<label>Chọn lớp: </label>";

    echo "<select id='lop' onchange='sendajax()'>";

    while ($row = mysqli_fetch_assoc($rs)) {

        echo "<option value='{$row['lop']}'>
              {$row['lop']}
              </option>";
    }

    echo "</select>";
}
?>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">

    <title>Ajax - Danh sách sinh viên</title>

    <style>
        body {
            font-family: Arial;
            margin: 30px;
            background: #f2f2f2;
        }

        h3 {
            color: navy;
        }

        #ds {
            margin-top: 20px;
            background: white;
            padding: 15px;
            width: 600px;
        }

        table {
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        th {
            background: navy;
            color: white;
        }
    </style>

    <script>
        function sendajax() {

            // Lấy lớp được chọn
            var lop = document.getElementById("lop").value;

            // Lấy vùng hiển thị dữ liệu
            var objds = document.getElementById("ds");

            // Tạo Ajax
            var xml = new XMLHttpRequest();

            // Nhận dữ liệu trả về từ server
            xml.onreadystatechange = function() {

                if (xml.readyState == 4 && xml.status == 200) {

                    // Hiển thị kết quả
                    objds.innerHTML = xml.responseText;
                }
            };

            // Gửi yêu cầu đến ds.php
            var url = "ds.php?lop=" + encodeURIComponent(lop);

            xml.open("GET", url, true);

            xml.send();
        }
    </script>

</head>

<body>

    <h3>In danh sách sinh viên theo từng lớp</h3>

    <?php
        initClass($con);
    ?>

    <hr>

    <div id="ds">
        Danh sách sinh viên sẽ hiển thị ở đây
    </div>

</body>

</html>
