<?php

include("inc/connect.inc");

// Nhận lớp từ Ajax
$lop = $_GET['lop'] ?? '';

// Truy vấn sinh viên theo lớp
$sql = "SELECT * FROM sinhvien WHERE lop = ?";

$stmt = mysqli_prepare($con, $sql);
mysqli_stmt_bind_param($stmt, "s", $lop);
mysqli_stmt_execute($stmt);

$rs = mysqli_stmt_get_result($stmt);

// Tạo bảng HTML
$str = "<table border='1' cellpadding='8'
        cellspacing='0' width='100%'>";

$str .= "
<tr style='background-color: navy; color: white;'>
    <th>TT</th>
    <th>Mã số</th>
    <th>Họ tên</th>
    <th>Địa chỉ</th>
</tr>
";

$tt = 1;

// Lấy dữ liệu sinh viên
while ($row = mysqli_fetch_assoc($rs)) {

    $str .= "
    <tr>
        <td>{$tt}</td>
        <td>{$row['masv']}</td>
        <td>{$row['hoten']}</td>
        <td>{$row['diachi']}</td>
    </tr>
    ";

    $tt++;
}

$str .= "</table>";

// Trả kết quả về Ajax
echo $str;

?>