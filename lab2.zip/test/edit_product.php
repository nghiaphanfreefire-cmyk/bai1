<?php
// Lấy dữ liệu từ form gửi lên
$product_id  = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
$category_id = filter_input(INPUT_POST, 'category_id', FILTER_VALIDATE_INT);
$code        = filter_input(INPUT_POST, 'code');
$name        = filter_input(INPUT_POST, 'name');
$price       = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);

// Kiểm tra dữ liệu hợp lệ
if ($product_id == false || $category_id == false || empty($code) || empty($name) || $price === false) {
    $error = "Invalid product data. Check all fields and try again.";
    echo "<p>$error</p>";
    include('database_error.php'); // Hoặc có thể tạo trang lỗi tùy ý
    exit();
}

// Kết nối database
require_once('database.php');

// Câu lệnh SQL cập nhật (UPDATE) sản phẩm
$query = 'UPDATE products 
          SET categoryID = :category_id,
              productCode = :code,
              productName = :name,
              listPrice = :price
          WHERE productID = :product_id';

$statement = $db->prepare($query);
$statement->bindValue(':category_id', $category_id);
$statement->bindValue(':code', $code);
$statement->bindValue(':name', $name);
$statement->bindValue(':price', $price);
$statement->bindValue(':product_id', $product_id);
$statement->execute();
$statement->closeCursor();

// Cập nhật xong chuyển hướng về trang danh sách sản phẩm thuộc danh mục đó
header("Location: index.php?category_id=$category_id");
exit();
?>