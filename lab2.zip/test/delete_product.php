<?php
// 1. Lấy dữ liệu product_id và category_id từ form POST
$product_id = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
$category_id = filter_input(INPUT_POST, 'category_id', FILTER_VALIDATE_INT);

// 2. Kiểm tra dữ liệu hợp lệ
if ($product_id != false && $category_id != false) {
    
    // Kết nối trực tiếp CSDL qua PDO
    $dsn = 'mysql:host=localhost;dbname=my_guitar_shop1';
    $username = 'root'; // Hoặc 'mgs_user' nếu bạn dùng tài khoản riêng trong file sql
    $password = '';     // Hoặc 'pa55word' nếu dùng mgs_user

    try {
        $db = new PDO($dsn, $username, $password);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // 3. Thực hiện câu lệnh xóa sản phẩm
        $query = 'DELETE FROM products WHERE productID = :product_id';
        $statement = $db->prepare($query);
        $statement->bindValue(':product_id', $product_id);
        $statement->execute();
        $statement->closeCursor();
        
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        echo "<p>Lỗi cơ sở dữ liệu: $error_message</p>";
        exit();
    }
}

// 4. Chuyển hướng về lại trang danh sách sản phẩm
header("Location: index.php?category_id=$category_id");
exit();
?>