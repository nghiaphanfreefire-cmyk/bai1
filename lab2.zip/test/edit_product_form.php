<?php
// Kết nối cơ sở dữ liệu để lấy thông tin sản phẩm cần sửa và danh sách categories
require_once('database.php');

// Lấy product_id từ phương thức GET hoặc POST
$product_id = filter_input(INPUT_GET, 'product_id', FILTER_VALIDATE_INT);
if (!$product_id) {
    $product_id = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
}

// Lấy thông tin chi tiết của sản phẩm đó lên để hiện thị vào form
$query = 'SELECT * FROM products WHERE productID = :product_id';
$statement = $db->prepare($query);
$statement->bindValue(':product_id', $product_id);
$statement->execute();
$product = $statement->fetch();
$statement->closeCursor();

// Lấy danh sách categories để hiển thị ra thẻ <select>
$queryCategories = 'SELECT * FROM categories ORDER BY categoryID';
$statementCategories = $db->prepare($queryCategories);
$statementCategories->execute();
$categories = $statementCategories->fetchAll();
$statementCategories->closeCursor();
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Guitar Shop</title>
    <link rel="stylesheet" type="text/css" href="ex4.css">
</head>
<body>
    <header><h1>Product Manager</h1></header>

    <main>
        <h1>Edit Product</h1>
        <form action="edit_product.php" method="post" id="edit_product_form">
            <!-- Truyền ẩn product_id đi để file xử lý biết sửa sản phẩm nào -->
            <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product['productID']); ?>">

            <label>Category:</label>
            <select name="category_id">
                <?php foreach ($categories as $category) : ?>
                    <option value="<?php echo $category['categoryID']; ?>" 
                        <?php if ($category['categoryID'] == $product['categoryID']) echo 'selected'; ?>>
                        <?php echo htmlspecialchars($category['categoryName']); ?>
                    </option>
                <?php endforeach; ?>
            </select><br>

            <label>Code:</label>
            <input type="text" name="code" value="<?php echo htmlspecialchars($product['productCode']); ?>"><br>

            <label>Name:</label>
            <input type="text" name="name" value="<?php echo htmlspecialchars($product['productName']); ?>"><br>

            <label>List Price:</label>
            <input type="text" name="price" value="<?php echo htmlspecialchars($product['listPrice']); ?>"><br>

            <label>&nbsp;</label>
            <input type="submit" value="Update Product"><br>
        </form>
        <p><a href="index.php">View Product List</a></p>
    </main>

    <footer>
        <p>&copy; 2026 My Guitar Shop, Inc.</p>
    </footer>
</body>
</html>