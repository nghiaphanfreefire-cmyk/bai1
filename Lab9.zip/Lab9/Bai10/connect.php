
<?php

$connect = mysqli_connect("localhost", "root", "");

if (!$connect) {
    die("Không thể kết nối Database: "
        . mysqli_connect_error());
}

mysqli_select_db($connect, "tintuc");

mysqli_query($connect, "SET NAMES 'utf8'");

?>
