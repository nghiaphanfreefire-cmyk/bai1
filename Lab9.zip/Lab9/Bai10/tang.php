
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Tang</title>
</head>

<body>

<a href="dem.php">Quay lai</a>

</body>
</html>
