
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>CKEditor - Posted Data</title>
</head>

<body>

<h2>NOI DUNG DA NHAP</h2>

<?php

if (isset($_POST["tomtat"])) {
    echo "<h3>Noi dung tom tat:</h3>";
    echo "<div style='border:1px solid #ccc;padding:10px'>";
    echo $_POST["tomtat"];
    echo "</div>";
}

if (isset($_POST["tomtat1"])) {
    echo "<h3>Noi dung chi tiet:</h3>";
    echo "<div style='border:1px solid #ccc;padding:10px'>";
    echo $_POST["tomtat1"];
    echo "</div>";
}

?>

<br>
<a href="index.php">Quay lai</a>

</body>
</html>
