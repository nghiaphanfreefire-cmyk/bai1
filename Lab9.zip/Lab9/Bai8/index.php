
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Bai 8 - Su dung CKEditor</title>

    <!-- Ket noi thu vien CKEditor -->
    <script src="ckeditor/ckeditor.js"></script>
</head>

<body>

<h2>BAI 8 - SU DUNG CKEDITOR</h2>

<form action="_posteddata.php" method="post">

    <p>Noi dung tom tat:</p>

    <textarea
        name="tomtat"
        id="tomtat"
        rows="10"
        cols="80">
    </textarea>

    <br><br>

    <p>Noi dung chi tiet:</p>

    <textarea
        name="tomtat1"
        id="tomtat1"
        rows="10"
        cols="80">
    </textarea>

    <br><br>

    <input type="submit" name="ok" value="OK">

</form>

<!-- Khoi tao CKEditor cho 2 textarea -->
<script type="text/javascript">

    CKEDITOR.replace('tomtat');

    CKEDITOR.replace('tomtat1');

</script>

</body>
</html>
